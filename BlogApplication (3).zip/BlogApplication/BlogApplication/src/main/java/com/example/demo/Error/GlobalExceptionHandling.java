package com.example.demo.Error;

public class GlobalExceptionHandling extends Exception{

    public GlobalExceptionHandling(String s)
    {
        super(s);
    }
}
